版本为3.7.2

解压后将application Loader
放到应用程序单独使用也可以

放到 /Applications/Xcode.app/Contents/Applications下也可以（和Xcode10一样，Xcode-open Developer Tools里面就有了）